<!DOCTYPE html>
<!-- saved from url=(0034)http://r96943ub.beget.tech/detail/ -->
<html lang="ru"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css?5">
    <link rel="stylesheet" href="css/media.css?4">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDK_4sEAN5_tM3Sq017L7UF0UKfxFVK9P8&callback=myMap" type="text/javascript"></script>
-->
    <script src="/js/jquery.fancybox.js"></script>

    <script src="/js/jquery.lettering.js"></script>
    <script src="/js/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js"></script>
    
    <!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(53114149, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/53114149" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
 
<!--
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/plugins/CSSPlugin.min.js"></script>
-->
    <script src="/js/main.js?4"></script>

    <title>PDL</title>
</head>

<body>
    <a href="#" class="go-to-up">Наверх</a>
<div class="menu_slide text-center">
    <div class="btn_close_menu" onclick="$('.menu_slide').slideToggle(500)"></div>
    <div class="nav_block">
        <a href="" class="item_menu">Что</a>
        <a href="#dlya_chego" class="item_menu dlya_chego_m">Для чего</a>
        <a href="#kak" class="item_menu">Как</a>
        <a href="#kto" class="item_menu">Кто</a>
        <a href="#gde" class="item_menu">Где</a>
        <a href="#card" class="item_menu open-modal">Подарочная карта</a>
        <a href="#filosof" class="item_menu open-modal">Философия компании</a>
    </div>
</div>
<div class="social_fixed">
    <a target="_blank" href="https://www.instagram.com/mypdl/?hl=ru" onclick="ym(53114149, 'reachGoal', 'instagramRedirect');return true;"><i class="fab fa-instagram"></i></a>
    <a target="_blank" href="https://vk.com/mypdl" onclick="ym(53114149, 'reachGoal', 'vkRedirect');return true;"><i class="fab fa-vk"></i></a>
    <a target="_blank" href="https://www.facebook.com/mypdl.ru/" onclick="ym(53114149, 'reachGoal', 'facebookRedirect');return true;"><i class="fab fa-facebook"></i></a>
</div>
<header class="header">
    <div class="container-fluid">
        <div class="content_header">
            <div class="logo_elements">
                <a href="" class="logo">
                    <img src="img/logo.png" alt="">
                </a>
                <p class="title_logo">Первый на Юге России центр психологических консультаций и коучинга</p>
            </div>
            <div class="nav_block">
                <a href="" class="item_menu">Что</a>
                <a href="#dlya_chego" class="item_menu dlya_chego_m">Для чего</a>
                <a href="#kak" class="item_menu">Как</a>
                <a href="#kto" class="item_menu">Кто</a>
                <a href="#gde" class="item_menu">Где</a>
                <a href="#card" class="item_menu open-modal">Подарочная карта</a>
                <a href="#filosof" class="item_menu open-modal">Философия компании</a>
            </div>
            <div class="btn_burger" onclick="$('.menu_slide').slideToggle(500)"></div>
        </div>
    </div>
</header>
<div class="section_top">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-5">
                <img src="img/head.png" class="mw-100" alt="">
            </div>
            <div class="col-12 col-lg-7">
                <h1 class="main_title">
                    Лаборатория
                    Совершенствования
                    Личности
                </h1>
                <div class="subtitle_main">
                    <span class="center">Работает над:</span><br><br>
                    <ul>
                        
                        <li>Повышением эффективности личности в различных<br>
                            областях деятельности</li>
                        <li>Гармонизацией взаимоотношений</li>
                        <li>Устранением психологических затруднений (тревожность, апатия, проблема принятия решений...)</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="section_2" id="dlya_chego">
    <div class="container">
        <div class="word_list">
            <div class="word_block_1">
                <div class="item item_1 blue">хочется быть<br/> эффективнее</div>
                <div class="item item_2">одиноко</div>
            </div>

            <div class="word_block_2">
                <div class="item item_3">страшно</div>
                <div class="item item_4 blue">Интересно<br/> самосовершенствование</div>
            </div>

            <div class="word_block_3">
                <div class="item item_5 blue wow"  data-wow-duration = "500" data-wow-delay = "2s">Пришло время<br/> побеждать</div>
                <div class="item item_6 wow"  data-wow-duration = "500" data-wow-delay = "2.5s">грустно</div>
                <div class="item item_7 wow"  data-wow-duration = "500" data-wow-delay = "3s">нужно<br/> больше смелости</div>
            </div>

            <div class="word_block_4">
                <div class="item item_8 wow"  data-wow-duration = "500" data-wow-delay = "3.5s">Важно понять,<br/> что происходит в моей жизни</div>
                <div class="item item_9 blue wow"  data-wow-duration = "500" data-wow-delay = "4s">Надо понять,чего я<br/> действительно<br/> хочу</div>
            </div>

            <div class="word_block_5">
                <div class="item item_10 blue wow"  data-wow-duration = "500" data-wow-delay = "4.5s">Необходимо больше<br/> удовольствий</div>
                <div class="item item_11 wow"  data-wow-duration = "500" data-wow-delay = "5s">почему-то<br/> ничего не хочется</div>
            </div>
        </div>
    </div>
</div>

<div class="section_3" id="kak">
    <div class="container">
        <h3>Personal Development Lab</h3>
        <div class="h3-hint">Стоимость одной двухчасовой консультации в нашем центре 5000 рублей</div>
        <div class="list_info_block">
            <div class="item">
                <div class="promo">
                    <div class="bottom">
                        <h4>Персональная консультация</h4>
                        <div class="open_content">Подробнее</div>
                    </div>
                </div>
                <div class="content_hidd">
                    <div class="fl_right"><div class="close"></div></div>
                    <h4>Персональная консультация</h4>
                    <p>Индивидуальна консультация, проводится профессиональным психологом. Работа над улучшением эмоционального состояния, через устранение психологических затруднений.</p>
                    <a href="#open_form" data-target="Персональная консультация" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item">
                <div class="promo">
                    <div class="bottom">
                        <h4>Парная консультация</h4>
                        <div class="open_content">Подробнее</div>
                    </div>
                </div>
                <div class="content_hidd">
                    <div class="fl_right"><div class="close"></div></div>
                    <h4>Парная консультация</h4>
                    <p>Парная консультация, проводится профессиональным психологом. Направлена на сохранение, улучшение и гармонизацию отношений между двумя.</p>
                    <a href="#open_form" data-target="Парная консультация" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item">
                <div class="promo">
                    <div class="bottom">
                        <h4>Коучинг</h4>
                        <div class="open_content">Подробнее</div>
                    </div>
                </div>
                <div class="content_hidd">
                    <div class="fl_right"><div class="close"></div></div>
                    <h4>Коучинг</h4>
                    <p>Индивидуальный коучинг, проводится профессиональным коучем. Разработка детализированных рекомендаций для достижения профессиональных, а также других жизненных целей и помощь в их постановке с учетом уникальных особенностей личности.</p>
                    <a href="#open_form" data-target="Коучинг" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item">
                <div class="promo">
                    <div class="bottom">
                        <h4>Корпоративный коучинг</h4>
                        <div class="open_content">Подробнее</div>
                    </div>
                </div>
                <div class="content_hidd">
                    <div class="fl_right"><div class="close"></div></div>
                    <h4>Корпоративный коучинг</h4>
                    <p>Тренинг для топ-менеджеров активно развивающихся компаний</p>
                    <a href="#open_form" data-target="Корпоративный коучинг" class="open_form zakaz">Записаться</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section_4" id="kto">
    <div class="container">
        <h3>Команда психологов</h3>
        <div class="list_command">
            <div class="item_command">
                <div class="img">
                    <img src="/img/alex.jpg">
                </div>
                <div class="name_btn">
                    <span>Алексей <br/>Проницательный и рассудительный</span><br>
                    <b>Коуч, психолог, специалист по индивидуальной работе</b>
                    <a href="#open_form" data-target="Алексей" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item_command">
                <div class="img">
                    <img src="/img/zoya.jpg">
                </div>
                <div class="name_btn">
                    <span>Зоя <br/>Чуткая и внимательная</span>
                    <br><b>Психолог, специалист по индивидуальной работе</b>
                    <a href="#open_form" data-target="Зоя" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item_command">
                <div class="img">
                    <img src="/img/mariya.jpg">
                </div>
                <div class="name_btn">
                    <span>Мария <br/>Яркая и заряжающая</span>
                    <br><b>Психолог, специалист по индивидуальной работе</b>
                    <a href="#open_form" data-target="Мария" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item_command">
                <div class="img">
                    <img src="/img/kate.jpg">
                </div>
                <div class="name_btn">
                    <span>Екатерина <br/>Располагающая и позитивная</span>
                    <br><b>Психолог, специалист по индивидуальной и парной работе</b>
                    <a href="#open_form" data-target="Екатерина" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item_command">
                <div class="img">
                    <img src="/img/kris.jpg">
                </div>
                <div class="name_btn">
                    <span>Кристина <br/>Раскрывающая женственность</span>
                    <br><b>Женский психолог, специалист по индивидуальной работе</b>
                    <a href="#open_form" class="open_form zakaz">Записаться</a>
                </div>
            </div>
            <div class="item_command">
                <div class="img">
                    <img src="/img/tanya.jpg">
                </div>
                <div class="name_btn">
                    <span>Татьяна <br/>Легкая и радушная</span>
                    <br><b>Психолог, специалист по индивидуальной работе</b>
                    <a href="#open_form" data-target="Татьяна" class="open_form zakaz">Записаться</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section_5" id="gde">
    <div >
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Abecdeede3e9d934a9ebd09f8d10e1800cc5b550cb6d37fda2d9cda84ebff507c&amp;width=100%25&amp;height=776&amp;lang=ru_UA&amp;scroll=false"></script>
    </div>
        <div class="adres">
        <h4>Контакты</h4>
        <div class="adress_text">
            <span>Краснодар, ул.Атарбекова<br/> 1/2, офис 8</span>
            <a href="tel:88003025580">8 (800) 302-55-80</a>
            <div class="social">
                <a target="_blank" href="https://www.instagram.com/mypdl/?hl=ru"><i class="fab fa-instagram"></i></a>
                <a target="_blank" href="https://vk.com/mypdl"><i class="fab fa-vk"></i></a>
                <a target="_blank" href="https://www.facebook.com/mypdl.ru/"><i class="fab fa-facebook"></i></a>
            </div>
            <a href="https://n197726.yclients.com/" target="_blank" data-target="Раздел с контактами" class="open_form zakaz">Записаться</a>
        </div>
    </div>
    <div class="copiright">
        <span>© Все права защищены. Создание и продвижение сайтов <a href="http://biz-com.info/">“BizCom”</a> </span>
    </div>
</div>

<div id="card" class="open-modal">
    <p>
        Подарочная карта дает возможность бесплатно получить консультацию специалиста Personal Development Lab.
        <a href="https://n197726.yclients.com/" target="_blank" data-target="Подарочная карта" class="open_form1 zakaz">Записаться</a>
    </p>
</div>

<div id="filosof" class="open-modal">
    <p>
        Философия нашей компании заключает в себе глубокое убеждение в возможности полного раскрытия внутреннего потенциала человека через работу с высококвалифицированными специалистами в области современной практической психологии, дополнительно прошедшими обучение по авторской методике Personal Development Lab.
        <br/><br/>
        Мы отказались от термина «психологическая проблема» потому, что не считаем полезным для работы с личностью позиционирование деструктивных установок, реализуемых психологическим механизмом в повседневной жизни, как заболевание. Для нас каждый человек здоров и полон позитивной силы для воплощения своих идей, своих самых великих мечтаний!
        <br/><br/>
        Наша миссия предложить Вам наставничество лучших психологов и коучей для развития способности к самоанализу.
        Также мы успешно составляем детализированные рекомендации для достижения людьми профессиональных и любых других жизненных целей.
        <br/><br/>
        Эти структурированные советы превращаются в методическое пособие по внедрению в существование способов ежедневно становиться счастливее, эффективнее, и улучшать качество любых типов взаимоотношений.
        <br/><br/>
        Фокус нашего внимания всегда центрирован на возможности создавать совместно с клиентами импульсы к их самосовершенствованию.
    </p>
</div>

<div id="open_form">
    <form id="form-main" method="post" action="/send.php">
        <div class="item">
            <input id="name" type="text" name="name" placeholder="Введите имя">
        </div>
        <div class="item">
            <input required="required" id="phone" type="text" name="phone" placeholder="+7 (999) 999 99 99">
        </div>
        <div class="item">
            <input id="mail" type="text" name="mail" placeholder="youremail@gmail.com">
        </div>
        <input  type="hidden" name="target" id="h-target" value="">
        
        <!--div id="g-recaptcha"></div-->
        
        <input type="submit" class="send-form" value="Записаться">
    </form>
</div>
<script type="text/javascript">
      /*var onloadCallback = function() {
        grecaptcha.render('g-recaptcha', {
          'sitekey' : '6LdYKJwUAAAAALrujylHJu5k4t6WCA7Jx96Voxo5'
        });
      };*/
    </script>

<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer>
</script>
<script>
    
    $(document).ready(function(){
        
        $('.open_form, .open_form1').click(function(){
            $('#h-target').val($(this).data('target'));
        });
        
        $("#phone").mask("+9 (999) 999 99 99");
        //$("#mail").mask("*@*.*");
        
        $('#name').keypress(function(key) { 
                if((key.charCode > 1105 || key.charCode < 1040) && (key.charCode != 45)) {return false; };
                
            });
        
        $('.send-form').click(function(e){
            
            
           
           if ($("#phone").val() === '' && $("#phone").val().indexOf('_') < 0){
               alert('Заполните поле телефон');
               return false;
               e.preventDefault();
           }
           
           var r = /^[\w\.\d-_]+@[\w\.\d-_]+\.\w{2,4}$/i;
           if ($('#mail').val() != ''){
            if (!r.test($('#mail').val())){
                alert('Некорректный адрес электронной почты');
                return false;
               e.preventDefault();
            }
           }

            ym(53114149, 'reachGoal', 'formSubmit');
            
        });
    });
    
</script>


<!--    <script>
        function myMap() {
            var mapCanvas = document.getElementById("map");
            var mapOptions = {
                center: new google.maps.LatLng(45.059396, 38.9492515), zoom: 16
            };
            var map = new google.maps.Map(mapCanvas, mapOptions);
        }
    </script>-->
<script src="/js/wow.js"></script>
<script>
    new WOW().init();
    
    <?php if (isset($_REQUEST['send'])) { ?>
        $(document).ready(function(){
         alert('Ваше сообщение успешно отправлено');   
        
        });
    <?php } ?>
    
</script>
</body>
</html>
